-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 11, 2020 at 03:01 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogging_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_category` varchar(255) NOT NULL,
  `post_category_id` int(11) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_content` text NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `post_image` text NOT NULL,
  `post_comment_count` int(11) NOT NULL,
  `post_views` int(11) NOT NULL,
  `post_tags` text NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  `post_track` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_title`, `post_category`, `post_category_id`, `post_author`, `post_content`, `post_date`, `post_image`, `post_comment_count`, `post_views`, `post_tags`, `post_status`, `post_track`) VALUES
(1, 'My first post', 'JavaScript', 1, 'Mahmoud', 'Hello World this is my first php ', 'Monday 10 August 2020', '../images/el_mohaseb0.PNG', 0, 0, 'first, post, js', 'draft', NULL),
(2, 'My second post', 'JavaScript', 1, 'mahmoud', 'Welcome dontnjasdfojikwaDAZ JPQEN RWSI', 'Monday 10 August 2020', '../images/myappp.PNG', 0, 0, 'hello, world', 'published', NULL),
(3, 'my final', 'JavaScript', 1, 'mahmoud', 'acfaspojdouhhadiqahpdhphaisjpdjsao', 'Monday 10 August 2020', '../images/myappp.PNG', 0, 0, 'test, ts1', 'published', NULL),
(4, 'fine', 'JavaScript', 1, 'mido', 'hello word', 'Monday 10 August 2020', '../images/mohseb2.PNG', 0, 0, 'first, second, third', 'published', NULL),
(5, 'hydi', 'JavaScript', 1, 'mido', 'Hello world php', 'Monday 10 August 2020', '../images/mohseb2.PNG', 0, 0, 'tested, first, mood', 'published', NULL),
(6, 'my new', 'HTML5', 2, 'mahmoud', 'New Poster', 'Tuesday 11 August 2020', '../images/mohseb2.PNG', 0, 0, 'more, again', 'published', NULL),
(7, 'hydi', 'JavaScript', 1, 'mahmoud', '<a href=\"#\">Hello</a>', 'Tuesday 11 August 2020', '../images/mohseb2.PNG', 0, 0, 'first, post, js', 'published', NULL),
(8, 'hydi', 'JavaScript', 1, 'mido', '<a href=\"users.php\">View All Users</a>', 'Tuesday 11 August 2020', '../images/mohseb2.PNG', 0, 0, 'first, post, js', 'published', NULL),
(9, 'My first post', 'JavaScript', 1, 'mahmoud', 'asaads', 'Tuesday 11 August 2020', '../images/myappp.PNG', 0, 0, 'hello, world', 'published', NULL),
(10, 'sasa', 'HTML5', 1, 'sasaas', 'assaassa', 'Tuesday 11 August 2020', '../images/', 0, 0, 'test, ts1', 'published', NULL),
(11, 'hello world', 'JavaScript', 1, 'sasasa', 'assaas', 'Tuesday 11 August 2020', '../images/', 0, 0, 'test, ts1', 'draft', NULL),
(12, 'My first post', 'HTML5', 1, 'mido', 'asssasa', 'Tuesday 11 August 2020', '../images/', 0, 0, 'first, post, js', 'published', NULL),
(13, 'My second post', 'JavaScript', 1, 'mido', 'saddsasas', 'Tuesday 11 August 2020', '../images/el_mohaseb0.PNG', 0, 0, 'first, second, third', 'draft', NULL),
(14, 'My second post', 'JavaScript', 1, 'mahmoud', '&lt;a href=&quot;#&quot;&gt;Hacked&lt;/a&gt;', 'Tuesday 11 August 2020', '../images/el_mohaseb0.PNG', 0, 0, 'first, post, js', 'published', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
