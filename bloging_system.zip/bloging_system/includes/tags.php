<?php 

$query = "SELECT post_tags FROM posts ORDER BY post_id DESC LIMIT 5";
$result = mysqli_query($con, $query);
?>

              <div class="sidebar-box blocked">
                <h3 class="heading">Tags</h3>
                <ul class="tags">

                <?php 
                   while ($row = mysqli_fetch_array($result)) {
                       echo "<li><a href='#'>" . $row['post_tags'] . "</a></li><br /><br />";
                   }
                ?>
                  
                </ul>
              </div>