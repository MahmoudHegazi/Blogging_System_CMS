<?php 
include "admin/includes/db.php";

function show_cat() {
   global $con;
   //$location = "/bloging_system";
   $query = "SELECT * FROM categories";
   $result = mysqli_query($con, $query);
   while ($row = mysqli_fetch_array($result)) {
	   $cat_id = $row['id'];
	   $cat_title = $row['category_name'];
             
        echo "<li class='nav-item'><a class='nav-link' href='catagory.php?cat_id=$cat_id'>$cat_title</a></li>";

       	   
   }
   
}
 
 

show_cat();



?>

