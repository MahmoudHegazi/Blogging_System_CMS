<?php 

  $query = "SELECT * FROM categories ORDER BY id DESC LIMIT 5";  
  $result = mysqli_query($con, $query);
  $count = mysqli_num_rows($result);
  
?>



            <div class="sidebar-box">
                <h3 class="heading">Categories <span style="float:right;">Posts</span></h3>
                <ul class="categories">
				<?php 
				while ($row = mysqli_fetch_array($result)) {
					$cat_id = $row['id'];					
					$cat_title = $row['category_name'];
				        $query2 = "SELECT * FROM posts WHERE post_category_id=$cat_id ";
					$res = mysqli_query($con, $query2);
					$postnum = mysqli_num_rows($res);
					
					echo "<li><a href='category.php?cat_id=$cat_id'>". $cat_title . "<span>" . $postnum . "</span></a></li>";
				} 
				
				?>
				
<!-- add catogries here -->
                </ul>
              </div>