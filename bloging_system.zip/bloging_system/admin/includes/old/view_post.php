<div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
  <thead>
    <th>Post ID</th>
    <th>Post Title</th>
    <th>Post Author</th>
    <th>Post Category</th>
    <th>Post Status</th>
    <th>Post Image</th>
    <th>Post Content</th>
    <th>Post Date</th>
    <th>Post Tags</th>
    <th>Post Comments</th>
    <th>Post Views</th>
    <th>Approve Post</th>
    <th>Unapprove Post</th>
    <th>Edit</th>
    <th>Delete</th>
  </thead>
  <tbody>
  <?php show_posts(); ?>
  </tbody>
</table>
</div>
